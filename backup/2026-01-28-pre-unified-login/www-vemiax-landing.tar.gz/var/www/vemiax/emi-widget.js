// Émi AI Chat Widget - Standalone version for static pages
// Version 2.1 - Fixed SVG icons and improved error handling
(function() {
  var API_URL = "https://api.vemiax.com/ai-chat/public";
  var PRIMARY_COLOR = "#3b82f6";
  var LANGUAGE = "hu";
  var MAX_RETRIES = 2;
  
  // Create styles
  var styles = document.createElement("style");
  styles.textContent = "\
    #emi-chat-btn {\
      position: fixed;\
      bottom: 24px;\
      right: 24px;\
      width: 60px;\
      height: 60px;\
      border-radius: 50%;\
      background: " + PRIMARY_COLOR + ";\
      border: none;\
      cursor: pointer;\
      box-shadow: 0 4px 20px rgba(0,0,0,0.3);\
      z-index: 9999;\
      transition: transform 0.3s, box-shadow 0.3s;\
      display: flex;\
      align-items: center;\
      justify-content: center;\
    }\
    #emi-chat-btn:hover {\
      transform: scale(1.1);\
      box-shadow: 0 6px 25px rgba(0,0,0,0.4);\
    }\
    #emi-chat-btn svg {\
      width: 28px;\
      height: 28px;\
      color: white;\
      fill: none;\
      stroke: currentColor;\
      stroke-width: 2;\
    }\
    #emi-chat-window {\
      position: fixed;\
      bottom: 100px;\
      right: 24px;\
      width: 380px;\
      max-width: calc(100vw - 48px);\
      max-height: calc(100vh - 150px);\
      background: white;\
      border-radius: 16px;\
      box-shadow: 0 10px 40px rgba(0,0,0,0.3);\
      z-index: 9998;\
      display: none;\
      flex-direction: column;\
      overflow: hidden;\
      animation: emi-slide-up 0.3s ease;\
    }\
    @keyframes emi-slide-up {\
      from { opacity: 0; transform: translateY(20px); }\
      to { opacity: 1; transform: translateY(0); }\
    }\
    #emi-chat-window.open { display: flex; }\
    #emi-chat-header {\
      background: " + PRIMARY_COLOR + ";\
      color: white;\
      padding: 16px;\
      display: flex;\
      align-items: center;\
      gap: 12px;\
    }\
    #emi-chat-header .avatar {\
      width: 40px;\
      height: 40px;\
      background: rgba(255,255,255,0.2);\
      border-radius: 50%;\
      display: flex;\
      align-items: center;\
      justify-content: center;\
      font-size: 20px;\
    }\
    #emi-chat-header .info { flex: 1; }\
    #emi-chat-header .info h3 { margin: 0; font-size: 16px; font-weight: 600; }\
    #emi-chat-header .info p { margin: 2px 0 0; font-size: 12px; opacity: 0.8; }\
    #emi-chat-close {\
      background: none;\
      border: none;\
      color: white;\
      cursor: pointer;\
      padding: 8px;\
      border-radius: 50%;\
      transition: background 0.2s;\
    }\
    #emi-chat-close:hover { background: rgba(255,255,255,0.2); }\
    #emi-chat-messages {\
      flex: 1;\
      overflow-y: auto;\
      padding: 16px;\
      background: #f8fafc;\
      min-height: 300px;\
      max-height: 400px;\
    }\
    .emi-msg {\
      margin-bottom: 12px;\
      display: flex;\
    }\
    .emi-msg.user { justify-content: flex-end; }\
    .emi-msg .bubble {\
      max-width: 80%;\
      padding: 10px 14px;\
      border-radius: 16px;\
      font-size: 14px;\
      line-height: 1.4;\
      white-space: pre-wrap;\
    }\
    .emi-msg.assistant .bubble {\
      background: white;\
      color: #1e293b;\
      border-bottom-left-radius: 4px;\
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);\
    }\
    .emi-msg.user .bubble {\
      background: " + PRIMARY_COLOR + ";\
      color: white;\
      border-bottom-right-radius: 4px;\
    }\
    .emi-typing {\
      display: flex;\
      gap: 4px;\
      padding: 10px 14px;\
    }\
    .emi-typing span {\
      width: 8px;\
      height: 8px;\
      background: #94a3b8;\
      border-radius: 50%;\
      animation: emi-bounce 1.4s infinite;\
    }\
    .emi-typing span:nth-child(2) { animation-delay: 0.2s; }\
    .emi-typing span:nth-child(3) { animation-delay: 0.4s; }\
    @keyframes emi-bounce {\
      0%, 60%, 100% { transform: translateY(0); }\
      30% { transform: translateY(-8px); }\
    }\
    #emi-chat-input-area {\
      padding: 12px;\
      background: white;\
      border-top: 1px solid #e2e8f0;\
      display: flex;\
      gap: 8px;\
    }\
    #emi-chat-input {\
      flex: 1;\
      padding: 10px 16px;\
      border: 1px solid #e2e8f0;\
      border-radius: 24px;\
      font-size: 14px;\
      outline: none;\
      transition: border-color 0.2s;\
    }\
    #emi-chat-input:focus { border-color: " + PRIMARY_COLOR + "; }\
    #emi-chat-send {\
      width: 40px;\
      height: 40px;\
      border-radius: 50%;\
      background: " + PRIMARY_COLOR + ";\
      border: none;\
      cursor: pointer;\
      display: flex;\
      align-items: center;\
      justify-content: center;\
      transition: opacity 0.2s, transform 0.2s;\
    }\
    #emi-chat-send:disabled { opacity: 0.5; cursor: not-allowed; }\
    #emi-chat-send:not(:disabled):hover { transform: scale(1.05); }\
    #emi-chat-send svg { width: 20px; height: 20px; color: white; fill: none; stroke: currentColor; stroke-width: 2; }\
    #emi-chat-footer {\
      padding: 8px;\
      text-align: center;\
      font-size: 11px;\
      color: #94a3b8;\
      background: white;\
    }\
    @media (max-width: 480px) {\
      #emi-chat-window {\
        bottom: 80px;\
        right: 12px;\
        left: 12px;\
        width: auto;\
      }\
      #emi-chat-btn {\
        bottom: 16px;\
        right: 16px;\
        width: 56px;\
        height: 56px;\
      }\
    }\
  ";
  document.head.appendChild(styles);
  
  // SVG icons
  var chatIcon = '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>';
  var closeIcon = '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>';
  var sendIcon = '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/></svg>';
  
  // Create button
  var btn = document.createElement("button");
  btn.id = "emi-chat-btn";
  btn.innerHTML = chatIcon;
  btn.title = "Beszélgess Émivel";
  document.body.appendChild(btn);
  
  // Create chat window
  var win = document.createElement("div");
  win.id = "emi-chat-window";
  win.innerHTML = '\
    <div id="emi-chat-header">\
      <div class="avatar">🤖</div>\
      <div class="info">\
        <h3>Émi</h3>\
        <p>VEMIAX AI Asszisztens</p>\
      </div>\
      <button id="emi-chat-close">\
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" xmlns="http://www.w3.org/2000/svg">\
          <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/>\
        </svg>\
      </button>\
    </div>\
    <div id="emi-chat-messages"></div>\
    <div id="emi-chat-input-area">\
      <input type="text" id="emi-chat-input" placeholder="Írd ide a kérdésed..." maxlength="500">\
      <button id="emi-chat-send">\
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/></svg>\
      </button>\
    </div>\
    <div id="emi-chat-footer">Émi AI-alapú asszisztens</div>\
  ';
  document.body.appendChild(win);
  
  var messagesEl = document.getElementById("emi-chat-messages");
  var inputEl = document.getElementById("emi-chat-input");
  var sendBtn = document.getElementById("emi-chat-send");
  var closeBtn = document.getElementById("emi-chat-close");
  
  var isOpen = false;
  var isLoading = false;
  var messages = [];
  var hasGreeted = false;
  
  function addMessage(role, content) {
    messages.push({ role: role, content: content });
    var div = document.createElement("div");
    div.className = "emi-msg " + role;
    div.innerHTML = '<div class="bubble">' + escapeHtml(content) + '</div>';
    messagesEl.appendChild(div);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }
  
  function escapeHtml(text) {
    var div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }
  
  function showTyping() {
    var div = document.createElement("div");
    div.className = "emi-msg assistant";
    div.id = "emi-typing";
    div.innerHTML = '<div class="bubble emi-typing"><span></span><span></span><span></span></div>';
    messagesEl.appendChild(div);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }
  
  function hideTyping() {
    var el = document.getElementById("emi-typing");
    if (el) el.remove();
  }
  
  // Fetch with retry and timeout
  function fetchWithRetry(url, options, retries) {
    retries = retries || MAX_RETRIES;
    return new Promise(function(resolve, reject) {
      var attempt = 0;
      
      function tryFetch() {
        attempt++;
        var controller = new AbortController();
        var timeoutId = setTimeout(function() { controller.abort(); }, 60000);
        
        var fetchOptions = Object.assign({}, options, { signal: controller.signal });
        
        fetch(url, fetchOptions)
          .then(function(res) {
            clearTimeout(timeoutId);
            if (!res.ok) throw new Error("HTTP " + res.status);
            return res.json();
          })
          .then(resolve)
          .catch(function(e) {
            clearTimeout(timeoutId);
            console.log("Émi API attempt " + attempt + " failed:", e.message);
            if (attempt <= retries) {
              setTimeout(tryFetch, 1000 * attempt);
            } else {
              reject(e);
            }
          });
      }
      
      tryFetch();
    });
  }
  
  function sendMessage() {
    var text = inputEl.value.trim();
    if (!text || isLoading) return;
    
    addMessage("user", text);
    inputEl.value = "";
    isLoading = true;
    sendBtn.disabled = true;
    showTyping();
    
    var history = messages.slice(-10).map(function(m) { 
      return { role: m.role, content: m.content }; 
    });
    
    fetchWithRetry(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text, conversationHistory: history, language: LANGUAGE })
    })
    .then(function(data) {
      hideTyping();
      addMessage("assistant", data.message || "Hmm, üres választ kaptam. Próbáld újra!");
    })
    .catch(function(e) {
      console.error("Émi chat error:", e);
      hideTyping();
      addMessage("assistant", "Hoppá, nem sikerült kapcsolódni! Kérlek próbáld újra pár másodperc múlva.");
    })
    .finally(function() {
      isLoading = false;
      sendBtn.disabled = false;
      inputEl.focus();
    });
  }
  
  function toggle() {
    isOpen = !isOpen;
    win.classList.toggle("open", isOpen);
    btn.innerHTML = isOpen ? closeIcon : chatIcon;
    
    if (isOpen && !hasGreeted) {
      addMessage("assistant", "Szia! Émi vagyok, a VEMIAX asszisztense. Miben segíthetek ma? 🚗✨");
      hasGreeted = true;
    }
    if (isOpen) inputEl.focus();
  }
  
  btn.addEventListener("click", toggle);
  closeBtn.addEventListener("click", toggle);
  sendBtn.addEventListener("click", sendMessage);
  inputEl.addEventListener("keypress", function(e) { if (e.key === "Enter") sendMessage(); });
})();
